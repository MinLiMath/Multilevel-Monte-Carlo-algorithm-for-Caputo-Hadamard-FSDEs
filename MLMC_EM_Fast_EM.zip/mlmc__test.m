% edited by Min Li, 2023/2/19
% this code tests the multi-level Monte Carlo Euler method
% on Example 1:
% {}_{CH}D_{a,t}^{\alpha}X(t) = -X(t) + \sin(X(t)) \frac{dW_t}{dt}          
% t\in [2,3], X(2)=1,
% i.e., X(t)= 1 + \frac{1}{\Gamma(\alpha)}
% \int_a^t (\log \frac ts)^{alpha-1} b(X(s))\frac{ds}{s} 
% + \frac{1}{\Gamma(\alpha)} 
% \int_a^t (\log \frac ts)^{alpha-1} \sigma(X(s))\frac{dW_s}{s}, t\in [2,3] 
% Also the CPU time. 
function mlmc__test

close all; clear all;
tic
  N = 20000;
  M = 4;
  randn('state',0);

%
% first, convergence tests
%
    L = 0:5;


  del1 = [];
  del2 = [];
  var1 = [];
  var2 = [];

  for l = L
    disp(sprintf('l = %d',l))
    sums = mlmc_l(M,l,N);    
    del1 = [del1 sums(3)/N ];
    del2 = [del2 sums(1)/N ];
    var1 = [var1 sums(4)/N-(sums(3)/N)^2 ];%Std MC
    var2 = [var2 sums(2)/N-(sums(1)/N)^2 ];%MLMC
  end

  disp(sprintf('value = %f',del1(length(L))))

%
% second, mlmc complexity tests
%
  Eps = [0.064 0.032 0.016 0.008 0.004];


  maxl = 0;

    extrap=0;
    for i = 1:length(Eps)
      eps = Eps(i);
      [P, Nl] = mlmc1(M,eps,@mlmc_l,extrap);
      l = length(Nl)-1;
      maxl = max(maxl,l);
      mlmc_cost(i,extrap+1) = (1+1/M)*sum(Nl.*M.^(2*(0:l)));
      std_cost(i,extrap+1)  = sum((2*var1((0:l)+1)/eps^2).*M.^(2*(0:l)));%why

      disp(sprintf('mlmc_cost = %d, std_cost = %d, savings = %f\n',...
         mlmc_cost(i,extrap+1),std_cost(i,extrap+1), ...
         std_cost(i,extrap+1)/ mlmc_cost(i,extrap+1)))
      Nls{i,extrap+1} = Nl; 
    end
 % end

  maxl = max(maxl,4);


%
% plot figures
%

  nvert = 2;
  figure; 

  set(0,'DefaultAxesColorOrder',[0 0 0]);
  set(0,'DefaultAxesLineStyleOrder','-*|--*|:*|-.*')

  subplot(nvert,2,1)
  plot(L,log(var1)/log(M),L(2:end),log(var2(2:end))/log(M))
  xlabel('l'); ylabel('log_M variance'); %title(stitle)
  legend('P_l','P_l- P_{l-1}')
  %axis([0 maxl -10 0])

  subplot(nvert,2,2)
  plot(L,log(abs(del1))/log(M), L(2:end),log(abs(del2(2:end)))/log(M))
  xlabel('l'); ylabel('log_M |mean|'); %title(stitle)
  legend('P_l','P_l- P_{l-1}')
 % axis([0 maxl -12 0])

  set(0,'DefaultAxesLineStyleOrder','--o|--x|--d|--*|--s|:o|:x|:d|:*|:s');


  subplot(nvert,2,2*nvert-1)
  semilogy(0:length(Nls{5,1})-1,Nls{5,1}, ...
           0:length(Nls{4,1})-1,Nls{4,1}, ...
           0:length(Nls{3,1})-1,Nls{3,1}, ...
           0:length(Nls{2,1})-1,Nls{2,1}, ...
           0:length(Nls{1,1})-1,Nls{1,1});%, ...
    xlabel('l'); ylabel('N_l'); %title(stitle)
    legend('\epsilon=0.004','\epsilon=0.008','\epsilon=0.016','\epsilon=0.032','\epsilon=0.064')

% 
    axis([0 maxl 5e0 1e7])

  subplot(nvert,2,2*nvert)
  loglog(Eps,std_cost(:,1)',Eps,mlmc_cost(:,1)')
   xlabel('\epsilon'); ylabel('Computational cost'); %title(stitle)
   legend('Std MC','MLMC')
   toc



%-------------------------------------------------------
%
% level l estimator
%

function sums = mlmc_l(M,l,N)

alpha=0.7;
 T=3;a=2; 
f1fun = @(y) -y;
f2fun = @(y) sin(y);
nf = M^l;
hf = (log(T)-log(a))/nf; %fine step
%hc = T/nc; %corse step


sums(1:4) = 0;

for N1 = 1:10000:N 
    N2 = min(10000,N-N1+1);


    X0 = 1;
    R=[1 M];Xmil=zeros(N2,2);
    %---------------------------------
    
    if l==0
      Xc = X0*ones(N2,1);
      dWf = sqrt(hf)*randn(N2,1);
      Xf  = ones(N2,1) + hf^(alpha)/gamma(1+alpha)*f1fun(Xc)+...
      (hf)^(alpha-1)/(gamma(alpha)*a)*f2fun(Xc).*dWf;
      Xmil(:,1)=Xf;
      Xmil(:,2)=Xc;
    else  
        dw=sqrt(hf)*randn(N2,nf); 
    for p=1:2
        Delta=R(p)*hf;L=floor(nf/R(p)); t=a*ones(1,L+1);
        for i=1:L
            t(i+1)=exp(log(a)+i*Delta);
        end
         y=zeros(N2,L+1);y(:,1)=ones(N2,1);
    
         y(:,2)=y(:,1)+(Delta)^(alpha)/gamma(1+alpha)*f1fun(y(:,1))+...
         (Delta)^(alpha-1)/(gamma(alpha)*t(1))*f2fun(y(:,1)).*sum(dw(:,R(p)*0+1:R(p)*1),2);
        for j=2:L
            c=zeros(N2,1);d=zeros(N2,1);
            for k=1:j
            Winc=sum(dw(:,R(p)*(k-1)+1:R(p)*k),2);
            c=c+(Delta)^(alpha)/gamma(1+alpha)*((j+1-k)^(alpha)-(j-k)^(alpha))*f1fun(y(:,k));
            d=d+(Delta)^(alpha-1)/(gamma(alpha)*t(k))*(j+1-k)^(alpha-1)*f2fun(y(:,k)).*Winc;
            end
            y(:,j+1)=ones(N2,1)+c+d; 
        end
        Xmil(:,p)=y(:,L+1);
    end
    end
    %---------------------------------
  Xf=Xmil(:,1); Xc=Xmil(:,2);
  sums(1) = sums(1) + sum(Xf-Xc);
  sums(2) = sums(2) + sum((Xf-Xc).^2);
  sums(3) = sums(3) + sum(Xf);
  sums(4) = sums(4) + sum(Xf.^2);
 end
 
